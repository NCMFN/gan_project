"""
askbisht_scraper.py
-------------------
Scrapes journal data from askbisht.com/journals with filters for:
  - subject, subsubject, indexing, paid status

Extracted fields per journal:
  1. Journal Title
  2. Publisher
  3. Review Time
  4. Quartile (Q1–Q4 / SJR)
  5. Free / Paid (APC status)
  6. ISSN
  7. Source URL

Requirements:
    pip install playwright pandas openpyxl
    playwright install chromium
"""

import asyncio
import json
import re
import time
import pandas as pd
from pathlib import Path
from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError

# ─────────────────────────────────────────────
#  CONFIG  ← edit these as needed
# ─────────────────────────────────────────────
TARGET_URL = (
    "https://askbisht.com/journals"
    "?subject=health-professions"
    "&subsubject=health-information-management"
    "&indexing=scopus"
    "&paid=no"
)

OUTPUT_CSV  = "askbisht_journals.csv"
OUTPUT_XLSX = "askbisht_journals.xlsx"

# How long (seconds) to wait for the page / elements
PAGE_TIMEOUT   = 30_000   # ms
DETAIL_TIMEOUT = 20_000   # ms

# Delay between journal detail page visits (be polite)
POLITENESS_DELAY = 1.2    # seconds


# ─────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────

def clean(text: str) -> str:
    """Strip whitespace from scraped text."""
    return text.strip() if text else "Not Available"


def parse_quartile(text: str) -> str:
    """Extract Q1/Q2/Q3/Q4 label from page text."""
    m = re.search(r'\b(Q[1-4])\b', text, re.IGNORECASE)
    return m.group(1).upper() if m else "Not Available"


def parse_review_time(text: str) -> str:
    """Extract review / publication time patterns."""
    patterns = [
        r'(\d+[\–\-]\d+\s*weeks?)',
        r'(\d+\s*weeks?)',
        r'(\d+[\–\-]\d+\s*days?)',
        r'(\d+\s*days?)',
        r'(\d+[\–\-]\d+\s*months?)',
        r'(\d+\s*months?)',
    ]
    for pat in patterns:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            return m.group(1).strip()
    return "Not Available"


# ─────────────────────────────────────────────
#  SCRAPING LOGIC
# ─────────────────────────────────────────────

async def get_journal_links(page) -> list[dict]:
    """
    Parse the listing page and return list of:
        {'title': ..., 'url': ..., 'quartile': ..., 'apc': ...}
    The listing page often already shows Q-rank and free/paid badges,
    so we harvest what we can here and fill the rest from detail pages.
    """
    journals = []

    # ── Try to find journal cards / rows ──
    # askbisht uses cards with class patterns like 'journal-card', 'journal-item', etc.
    # We try several selectors and fall back to link scanning.
    card_selectors = [
        "div.journal-card",
        "div.journal-item",
        "div[class*='journal']",
        "article",
        "tr.journal-row",
        "li.journal",
    ]

    cards = []
    for sel in card_selectors:
        found = await page.query_selector_all(sel)
        if found:
            print(f"  → Found {len(found)} journal cards with selector: {sel}")
            cards = found
            break

    if cards:
        for card in cards:
            text = await card.inner_text()
            link_el = await card.query_selector("a[href*='journal']")
            if not link_el:
                link_el = await card.query_selector("a")

            href = await link_el.get_attribute("href") if link_el else ""
            title_el = await card.query_selector("h2, h3, h4, .journal-title, .title")
            title = await title_el.inner_text() if title_el else (await link_el.inner_text() if link_el else "")

            # Quartile from listing card
            q = parse_quartile(text)

            # APC from listing badge
            apc = "Free" if re.search(r'\bfree\b', text, re.IGNORECASE) else \
                  "Paid" if re.search(r'\bpaid\b|\bapc\b|\bfee\b', text, re.IGNORECASE) else \
                  "Not Available"

            # Build full URL
            if href and not href.startswith("http"):
                href = "https://askbisht.com" + href

            if href:
                journals.append({
                    "title":    clean(title),
                    "url":      href,
                    "quartile": q,
                    "apc":      apc,
                })
    else:
        # Fallback: scan all <a> tags pointing to journal detail pages
        links = await page.query_selector_all("a[href*='journal']")
        print(f"  → Fallback: found {len(links)} journal links via <a> scan")
        seen = set()
        for link in links:
            href = await link.get_attribute("href") or ""
            if not href or href in seen:
                continue
            seen.add(href)
            if not href.startswith("http"):
                href = "https://askbisht.com" + href
            title = await link.inner_text()
            journals.append({
                "title":    clean(title),
                "url":      href,
                "quartile": "Not Available",
                "apc":      "Not Available",
            })

    return journals


async def scrape_detail(page, url: str) -> dict:
    """Visit a journal detail page and extract all required fields."""
    detail = {
        "Publisher":   "Not Available",
        "ISSN":        "Not Available",
        "Review Time": "Not Available",
        "Quartile":    "Not Available",
        "APC":         "Not Available",
    }

    try:
        await page.goto(url, timeout=DETAIL_TIMEOUT, wait_until="domcontentloaded")
        await page.wait_for_timeout(1500)   # let JS settle

        text = await page.inner_text("body")

        # ── Publisher ──
        pub_patterns = [
            r'Publisher[:\s]+([^\n\r|]+)',
            r'Published by[:\s]+([^\n\r|]+)',
        ]
        for pat in pub_patterns:
            m = re.search(pat, text, re.IGNORECASE)
            if m:
                val = m.group(1).strip().rstrip('|').strip()
                if val:
                    detail["Publisher"] = val
                    break

        # ── ISSN ──
        issn_m = re.search(r'(?:ISSN|eISSN|pISSN)[:\s]+([0-9X]{4}-[0-9X]{4})', text, re.IGNORECASE)
        if issn_m:
            detail["ISSN"] = issn_m.group(1).strip()

        # ── Review Time ──
        detail["Review Time"] = parse_review_time(text)

        # ── Quartile ──
        detail["Quartile"] = parse_quartile(text)

        # ── APC / Free ──
        if re.search(r'no\s+(article\s+)?processing\s+charge|apc[:\s]*free|publication\s+fee[:\s]*0|free\s+to\s+publish|does not charge', text, re.IGNORECASE):
            detail["APC"] = "Free"
        elif re.search(r'article\s+processing\s+charge|apc[:\s]*\$|publication\s+fee', text, re.IGNORECASE):
            # Try to pull the fee amount
            fee_m = re.search(r'(?:APC|fee)[:\s]*\$?([\d,]+)', text, re.IGNORECASE)
            detail["APC"] = f"Paid – ${fee_m.group(1)}" if fee_m else "Paid"
        elif re.search(r'\bfree\b', text, re.IGNORECASE):
            detail["APC"] = "Free"

    except PlaywrightTimeoutError:
        print(f"    ⚠ Timeout on {url}")
    except Exception as exc:
        print(f"    ⚠ Error on {url}: {exc}")

    return detail


async def handle_pagination(page) -> bool:
    """
    Click 'Next' / '›' pagination button if present.
    Returns True if navigation happened, False if no more pages.
    """
    next_selectors = [
        "a[aria-label='Next']",
        "a[rel='next']",
        "a.next",
        "button.next",
        "li.next a",
        "a:has-text('Next')",
        "a:has-text('›')",
        "a:has-text('»')",
    ]
    for sel in next_selectors:
        btn = await page.query_selector(sel)
        if btn:
            disabled = await btn.get_attribute("disabled") or \
                       await btn.get_attribute("aria-disabled")
            classes  = await btn.get_attribute("class") or ""
            if disabled or "disabled" in classes:
                return False
            await btn.click()
            await page.wait_for_load_state("domcontentloaded")
            await page.wait_for_timeout(2000)
            return True
    return False


# ─────────────────────────────────────────────
#  MAIN
# ─────────────────────────────────────────────

async def main():
    print("=" * 60)
    print("AskBisht Journal Scraper")
    print(f"Target: {TARGET_URL}")
    print("=" * 60)

    all_journals: list[dict] = []

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(
            headless=True,
            args=[
                "--no-sandbox",
                "--disable-blink-features=AutomationControlled",
            ],
        )

        # Realistic browser context
        context = await browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/124.0.0.0 Safari/537.36"
            ),
            viewport={"width": 1280, "height": 900},
            locale="en-US",
        )
        # Hide automation hints
        await context.add_init_script(
            "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
        )

        list_page = await context.new_page()

        print(f"\n[1/3] Loading listing page …")
        try:
            await list_page.goto(TARGET_URL, timeout=PAGE_TIMEOUT, wait_until="domcontentloaded")
            await list_page.wait_for_timeout(3000)   # wait for JS to render
        except PlaywrightTimeoutError:
            print("  ⚠ Page load timed out. Proceeding with what loaded.")

        # Collect across all listing pages
        page_num = 1
        while True:
            print(f"  → Listing page {page_num} …")
            links = await get_journal_links(list_page)
            print(f"     {len(links)} journals found on this listing page.")
            all_journals.extend(links)

            has_next = await handle_pagination(list_page)
            if not has_next:
                break
            page_num += 1

        print(f"\n[2/3] Scraping detail pages for {len(all_journals)} journals …\n")

        detail_page = await context.new_page()
        results = []

        for i, journal in enumerate(all_journals, 1):
            print(f"  [{i}/{len(all_journals)}] {journal['title'][:70]}")
            detail = await scrape_detail(detail_page, journal["url"])

            row = {
                "Journal Title": journal["title"],
                "Publisher":     detail["Publisher"],
                "ISSN":          detail["ISSN"],
                "Review Time":   detail["Review Time"],
                "Quartile":      detail["Quartile"] if detail["Quartile"] != "Not Available"
                                 else journal["quartile"],
                "APC":           detail["APC"] if detail["APC"] != "Not Available"
                                 else journal["apc"],
                "Source URL":    journal["url"],
            }
            results.append(row)
            print(f"     Publisher: {row['Publisher']}  |  Quartile: {row['Quartile']}  "
                  f"|  APC: {row['APC']}  |  Review: {row['Review Time']}")

            await asyncio.sleep(POLITENESS_DELAY)

        await browser.close()

    # ── Export ──────────────────────────────────────────────
    print(f"\n[3/3] Exporting {len(results)} records …")

    df = pd.DataFrame(results)

    df.to_csv(OUTPUT_CSV, index=False)
    print(f"  ✓ CSV  → {OUTPUT_CSV}")

    with pd.ExcelWriter(OUTPUT_XLSX, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Journals")

        # Auto-size columns
        ws = writer.sheets["Journals"]
        for col in ws.columns:
            max_len = max(len(str(cell.value or "")) for cell in col)
            ws.column_dimensions[col[0].column_letter].width = min(max_len + 4, 60)

    print(f"  ✓ XLSX → {OUTPUT_XLSX}")

    # ── Summary ─────────────────────────────────────────────
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"Total journals scraped : {len(df)}")

    if "Quartile" in df.columns:
        print("\nQuartile distribution:")
        print(df["Quartile"].value_counts().to_string())

    if "APC" in df.columns:
        print("\nAPC distribution:")
        print(df["APC"].value_counts().to_string())

    missing_review = (df["Review Time"] == "Not Available").sum()
    print(f"\nMissing review time    : {missing_review}")
    print("\nDone ✓")


if __name__ == "__main__":
    asyncio.run(main())
