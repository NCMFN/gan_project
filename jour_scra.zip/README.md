# AskBisht Journal Scraper

Scrapes Scopus-indexed journal metadata from **askbisht.com/journals** and exports
the results to CSV and Excel.

## Fields collected

| Field | Notes |
|---|---|
| Journal Title | Full journal name |
| Publisher | Publishing organisation |
| ISSN | Print or electronic ISSN |
| Review Time | Typical turnaround (weeks / months) |
| Quartile | SJR Q1–Q4 ranking |
| APC | Free / Paid (with fee amount if stated) |
| Source URL | Direct link to the journal page |

---

## Quick-start

### 1. Install Python dependencies

```bash
pip install -r requirements.txt
```

### 2. Install the Playwright browser (one-time)

```bash
playwright install chromium
```

### 3. Run the scraper

```bash
python askbisht_scraper.py
```

Output files created in the same directory:

- `askbisht_journals.csv`
- `askbisht_journals.xlsx`

---

## Changing the target URL / filters

Open `askbisht_scraper.py` and edit the `TARGET_URL` constant at the top:

```python
TARGET_URL = (
    "https://askbisht.com/journals"
    "?subject=health-professions"
    "&subsubject=health-information-management"
    "&indexing=scopus"
    "&paid=no"
)
```

Available filter parameters (combine as needed):

| Parameter | Example values |
|---|---|
| `subject` | `health-professions`, `medicine`, `engineering` |
| `subsubject` | `health-information-management`, `nursing` |
| `indexing` | `scopus`, `wos` |
| `paid` | `no` (free journals only), `yes`, *(omit for all)* |

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `403 Forbidden` on first load | The scraper uses a real Chromium browser, so this shouldn't happen. If it persists, set `headless=False` in `askbisht_scraper.py` to see what the browser shows. |
| All fields say "Not Available" | The site may have changed its HTML structure. Open a journal detail page manually and inspect the field labels, then update the regex patterns in `scrape_detail()`. |
| Slow scraping | Increase `POLITENESS_DELAY` if you get rate-limited; decrease it (min ~0.5 s) for speed. |
| Missing quartile data | Quartile is sometimes on the listing card, sometimes only on the detail page. Both places are checked automatically. |

---

## Project structure

```
├── askbisht_scraper.py   ← main scraper (this repo)
├── journal_scraper.py    ← original journalsearches.com scraper (kept for reference)
├── requirements.txt
└── README.md
```
